function addToCart(){
    document.getElementById("added-msg").innerHTML="Item added to Cart Successfully";
    //return false;
}

function deleteFromCart(){
    document.getElementById("added-msg").innerHTML="Item removed from Cart successfully";
    //return false;
}